<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Restaurant Owner Dashboard - Menu Management</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
    <nav class="navbar">
        <a href="${pageContext.request.contextPath}/home.jsp" class="brand">
            <div class="brand-icon">B</div>
            Owner Dashboard
        </a>
        <div class="nav-right">
            <a href="${pageContext.request.contextPath}/logout" class="btn-outline-sm">Logout</a>
        </div>
    </nav>

    <div class="main-layout" style="grid-template-columns: 1fr;">
        <div class="auth-card" style="max-width: 100%; margin-bottom: 2rem;">
            <h2 class="section-title">Add New Menu Item</h2>
            <form id="addMenuForm">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label>Item Name</label>
                        <input type="text" name="name" class="form-control" required placeholder="e.g., Pepperoni Pizza">
                    </div>
                    <div class="form-group">
                        <label>Price (Rs.)</label>
                        <input type="number" step="0.01" name="price" class="form-control" required placeholder="299.00">
                    </div>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label>Category</label>
                        <input type="text" name="category" class="form-control" placeholder="Pizza, Burger, Drinks">
                    </div>
                    <div class="form-group">
                        <label>Stock Quantity</label>
                        <input type="number" name="stockQty" class="form-control" value="50">
                    </div>
                </div>
                <div class="form-group">
                    <label>Image URL</label>
                    <input type="url" name="imageUrl" class="form-control" placeholder="https://images.unsplash.com/...">
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" class="form-control" rows="2" placeholder="Delicious cheesy description..."></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Add Item to Menu</button>
            </form>
        </div>
    </div>

    <script>
        const ctx = '${pageContext.request.contextPath}';

        document.getElementById('addMenuForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const formData = new URLSearchParams(new FormData(e.target));

            fetch(ctx + '/api/v1/owner/menu-items', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: formData
            })
            .then(res => res.json())
            .then(res => {
                if (res.success) {
                    alert('Menu item added successfully to the database!');
                    e.target.reset();
                } else {
                    alert(res.error ? res.error.message : 'Failed to add item.');
                }
            })
            .catch(err => console.error('Error:', err));
        });
    </script>
</body>
</html>