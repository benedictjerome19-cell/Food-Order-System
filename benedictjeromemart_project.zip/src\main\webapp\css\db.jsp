<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Live Database Viewer</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <style>
        .db-container {
            padding: 2rem;
            background: var(--bg-surface);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border-glass);
            border-radius: var(--radius-md);
            margin: 2rem auto;
            max-width: 1000px;
        }
        table { width: 100%; border-collapse: collapse; margin-top: 1rem; color: var(--text-main); }
        th, td { border: 1px solid var(--border-glass); padding: 12px; text-align: left; }
        th { background: rgba(255, 59, 48, 0.15); color: var(--primary); font-family: 'Plus Jakarta Sans', sans-serif; }
        tr:hover { background: rgba(255, 255, 255, 0.03); }
    </style>
</head>
<body>
    <nav class="navbar">
        <a href="${pageContext.request.contextPath}/home.jsp" class="brand">
            <div class="brand-icon">B</div>
            Admin Database Viewer
        </a>
    </nav>

    <div class="db-container">
        <h2 class="section-title">Live Render Database</h2>
        
        <%
            // Your exact working connection string from the terminal script
            String url = "jdbc:postgresql://dpg-dan44m142hec73d535bg-a.oregon-postgres.render.com:5432/benedictjeromemart_db?sslmode=require";
            String dbUser = "benedictjeromemart_db_user";
            String dbPass = "3hAmYmzSSwaSTy9mDgUO7bs9AgiEsrQ4";

            try {
                // Ensure the PostgreSQL driver is loaded for the web server
                Class.forName("org.postgresql.Driver");
                
                try (Connection conn = DriverManager.getConnection(url, dbUser, dbPass);
                     Statement stmt = conn.createStatement()) {
                     
                    // --- 1. Draw Users Table ---
                    out.println("<h3 style='margin-top:1rem;'>👤 Users Table</h3>");
                    ResultSet rsUsers = stmt.executeQuery("SELECT id, name, email, role FROM users ORDER BY id ASC LIMIT 50;");
                    
                    out.println("<table><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th></tr>");
                    while (rsUsers.next()) {
                        out.println("<tr>");
                        out.println("<td>" + rsUsers.getInt("id") + "</td>");
                        out.println("<td>" + rsUsers.getString("name") + "</td>");
                        out.println("<td>" + rsUsers.getString("email") + "</td>");
                        out.println("<td><span class='category-badge' style='position:static;'>" + rsUsers.getString("role") + "</span></td>");
                        out.println("</tr>");
                    }
                    out.println("</table>");
                    
                    // --- 2. Draw Menu Items Table ---
                    out.println("<h3 style='margin-top:3rem;'>🍔 Menu Items Table</h3>");
                    ResultSet rsMenu = stmt.executeQuery("SELECT id, name, price FROM menu_items ORDER BY id ASC LIMIT 50;");
                    
                    out.println("<table><tr><th>ID</th><th>Name</th><th>Price</th></tr>");
                    while (rsMenu.next()) {
                        out.println("<tr>");
                        out.println("<td>" + rsMenu.getInt("id") + "</td>");
                        out.println("<td>" + rsMenu.getString("name") + "</td>");
                        out.println("<td><strong style='color:var(--accent-gold);'>Rs. " + rsMenu.getBigDecimal("price") + "</strong></td>");
                        out.println("</tr>");
                    }
                    out.println("</table>");
                    
                }
            } catch (Exception e) {
                out.println("<div class='alert-message alert-error'><strong>Connection Error:</strong> " + e.getMessage() + "</div>");
            }
        %>
    </div>
</body>
</html>