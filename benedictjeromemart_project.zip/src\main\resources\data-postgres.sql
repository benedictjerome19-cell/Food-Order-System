BEGIN;
INSERT INTO users (id, name, email, password, role, created_at) VALUES
(1, 'Admin', 'admin@yournameeats.com', '$2a$10$MQJkELMJPjs6y9DJ1mVTweB/7jwnBd4Tel8JSS9AbtzDsug1UAxpG', 'ADMIN', TIMESTAMP '2026-08-09 11:58:25.41082'),
(2, 'Test Owner', 'owner@test.com', '$2a$10$KKrvdMt9a58vnldV55FOQ.WBZvfOLzVcS7ZGkc2BVPQi.i.hQntti', 'RESTAURANT_OWNER', TIMESTAMP '2026-08-09 11:58:25.422674'),
(3, 'Test Customer', 'customer@test.com', '$2a$10$Lnt/cyR2MpYMdXhfExt.9e/42nPgeMX90sYCXuuzVW.dDiuf03TFO', 'CUSTOMER', TIMESTAMP '2026-08-09 11:58:25.422674'),
(4, 'jenifer', 'jenifermary123@gmail.com', '$2a$10$8vQzeno1safptWttYGeFue7LZQWN//RVJllVt6jQY9vJOqJOX74lO', 'CUSTOMER', TIMESTAMP '2026-08-09 12:02:02.041805'),
(5, 'micheal', 'micheal@123', '$2a$10$W92i6XBO/dZhpaPDN36V3.tO0SyQvhChoILTG./G7BtcTHfOIFYNK', 'CUSTOMER', TIMESTAMP '2026-08-09 12:04:46.267505'),
(33, 'bomitra', 'bomitra@123', '$2a$10$OoXyNkXyCo2C3eqBlTUN4.oUqO2PUjjWSNavoLGfUWleeZ/CRcxDe', 'RESTAURANT_OWNER', TIMESTAMP '2026-08-09 13:13:38.01064'),
(65, 'karki_pookie', 'karki@123gmail.com', '$2a$10$NDc3DtGhIMrx7OMNzrwz9OVcTt2bM9.8zZjM//PtmOJ5kuhUGligi', 'CUSTOMER', TIMESTAMP '2026-08-10 10:51:20.795433'),
(97, 'bala', 'bala@123gmail.com', '$2a$10$/ENe7kcDaMLBYYmyiHC3A.u/wNVbxwv3rMpkygxoR/U/2En9Wjm7m', 'CUSTOMER', TIMESTAMP '2026-09-19 09:36:37.08011')
ON CONFLICT DO NOTHING;

INSERT INTO restaurants (id, owner_id, name, cuisine_type, address, created_at) VALUES
(1, 1, 'Tasty Bites', 'North Indian & Mains', '123 Main Street', TIMESTAMP '2026-08-09 11:58:25.422674'),
(2, 1, 'Royal Awadh Palace', 'Biryanis & Kebabs', '45 Grand Boulevard', TIMESTAMP '2026-08-09 11:58:25.422674'),
(3, 1, 'Dragon Wok Express', 'Pan-Asian & Chinese', '88 Silk Route Arcade', TIMESTAMP '2026-08-09 11:58:25.422674'),
(4, 1, 'Piazza Italia Bistro', 'Pizzas & Burgers', '12 Venice Plaza', TIMESTAMP '2026-08-09 11:58:25.422674'),
(5, 1, 'South Tiffin House', 'South Indian Specialties', '99 Temple Road', TIMESTAMP '2026-08-09 11:58:25.422674'),
(6, 1, 'Sweet Tooth Bakery', 'Desserts & Drinks', '7 Bakery Street', TIMESTAMP '2026-08-09 11:58:25.422674')
ON CONFLICT (id) DO NOTHING;

INSERT INTO menu_items (id, restaurant_id, name, description, price, stock_qty, category, image_url, created_at) VALUES
(1, 1, 'Paneer Butter Masala', 'Creamy tomato-based curry', 220.00, 50, 'Mains', '', TIMESTAMP '2026-08-09 11:58:25.428055'),
(2, 1, 'Veg Biryani', 'Fragrant rice with vegetables', 180.00, 40, 'Mains', '', TIMESTAMP '2026-08-09 11:58:25.428055'),
(3, 1, 'Gulab Jamun', 'Sweet milk-based dessert', 90.00, 60, 'Desserts', '', TIMESTAMP '2026-08-09 11:58:25.428055'),
(33, 1, 'Paneer Tikka Masala', 'Grilled paneer in spiced tomato-onion gravy', 240.00, 40, 'Mains', 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(34, 1, 'Shahi Paneer', 'Royal creamy paneer cooked in cashew-saffron sauce', 260.00, 35, 'Mains', 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(35, 1, 'Palak Paneer', 'Fresh paneer cubes in smooth spinach gravy', 220.00, 45, 'Mains', 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(36, 1, 'Kadai Paneer', 'Paneer with capsicum in tangy kadai spices', 230.00, 40, 'Mains', 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(37, 1, 'Paneer Lababdar', 'Rich tomato-cashew gravy with soft paneer', 255.00, 30, 'Mains', 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(38, 1, 'Paneer Korma', 'Paneer in mild sweet yogurt and nut gravy', 245.00, 30, 'Mains', 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(39, 1, 'Paneer Do Pyaza', 'Double-onion paneer dry curry with aromatic spices', 225.00, 35, 'Mains', 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(40, 1, 'Matar Paneer', 'Green peas and paneer in spiced tomato gravy', 215.00, 40, 'Mains', 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(41, 1, 'Paneer Masala', 'Classic North Indian paneer in spicy masala sauce', 230.00, 35, 'Mains', 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(42, 1, 'Paneer Bhurji', 'Scrambled paneer with onion, tomato and spices', 195.00, 40, 'Mains', 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(43, 1, 'Butter Chicken', 'Tender chicken in velvety tomato-butter gravy', 18.99, 50, 'Mains', 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(44, 1, 'Chicken Tikka Masala', 'Grilled chicken in rich masala sauce', 290.00, 45, 'Mains', 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(45, 1, 'Chicken Korma', 'Tender chicken in mild yogurt and cashew gravy', 270.00, 35, 'Mains', 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(46, 1, 'Chicken Do Pyaza', 'Chicken cooked with double the onions, bold flavors', 265.00, 35, 'Mains', 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(47, 1, 'Chicken Vindaloo', 'Fiery Goan-style chicken in tangy vinegar gravy', 275.00, 30, 'Mains', 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(48, 1, 'Chicken Chettinad', 'South Indian spiced chicken with aromatic chettinad masala', 285.00, 30, 'Mains', 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(49, 1, 'Chicken Saag', 'Chicken cooked with fresh spinach and fenugreek', 260.00, 35, 'Mains', 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(50, 1, 'Chicken Rogan Josh', 'Kashmiri slow-cooked chicken with whole spices', 290.00, 30, 'Mains', 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281')
ON CONFLICT DO NOTHING;

INSERT INTO menu_items (id, restaurant_id, name, description, price, stock_qty, category, image_url, created_at) VALUES
(51, 1, 'Chicken Cafreal', 'Goan herb-marinated grilled chicken', 275.00, 25, 'Mains', 'https://images.unsplash.com/photo-1600891964092-4316c288032e?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(52, 1, 'Chicken Keema Masala', 'Spiced minced chicken with peas in rich gravy', 255.00, 35, 'Mains', 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(53, 2, 'Mutton Biryani', 'Tender mutton pieces in fragrant long-grain basmati', 350.00, 25, 'Mains', 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(54, 2, 'Prawn Biryani', 'Succulent prawns layered with saffron-infused rice', 380.00, 20, 'Mains', 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(55, 2, 'Egg Biryani', 'Soft-boiled eggs cooked with fragrant biryani rice', 220.00, 35, 'Mains', 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(56, 2, 'Hyderabadi Biryani', 'Authentic Hyderabadi dum-cooked chicken biryani', 310.00, 30, 'Mains', 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(57, 2, 'Jeera Rice', 'Basmati rice tempered with cumin and ghee', 120.00, 60, 'Mains', 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(58, 2, 'Peas Pulao', 'Fragrant basmati with fresh green peas and whole spices', 150.00, 50, 'Mains', 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(59, 2, 'Lemon Rice', 'Tangy South Indian lemon rice with peanuts and curry leaf', 130.00, 50, 'Mains', 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(60, 2, 'Curd Rice', 'Cooling South Indian curd rice with tempering', 110.00, 50, 'Mains', 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(61, 2, 'Veg Fried Rice', 'Wok-tossed rice with fresh vegetables in soy sauce', 160.00, 45, 'Mains', 'https://images.unsplash.com/photo-1512058564366-18510be2db19?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(62, 2, 'Egg Fried Rice', 'Classic fried rice with scrambled egg and spring onion', 180.00, 40, 'Mains', 'https://images.unsplash.com/photo-1512058564366-18510be2db19?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(63, 1, 'Dal Tadka', 'Yellow lentils tempered with ghee, cumin and garlic', 170.00, 55, 'Mains', 'https://images.unsplash.com/photo-1546833998-877b37c2e5c6?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(64, 1, 'Dal Fry', 'Masoor dal fried with onion, tomato and spices', 160.00, 55, 'Mains', 'https://images.unsplash.com/photo-1546833998-877b37c2e5c6?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(65, 1, 'Sambar', 'Tangy tamarind lentil soup with vegetables', 120.00, 60, 'Mains', 'https://images.unsplash.com/photo-1546833998-877b37c2e5c6?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(66, 1, 'Rajma Masala', 'Kidney beans slow-cooked in tangy Punjabi masala', 190.00, 45, 'Mains', 'https://images.unsplash.com/photo-1546833998-877b37c2e5c6?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(67, 1, 'Chhole Masala', 'Spiced chickpeas in thick North Indian masala sauce', 195.00, 45, 'Mains', 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(68, 5, 'Masala Dosa', 'Crispy crepe filled with spiced potato filling', 130.00, 60, 'Mains', 'https://images.unsplash.com/photo-1630383249896-424e482df921?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(69, 5, 'Plain Dosa', 'Thin crispy rice and lentil crepe with chutney', 100.00, 60, 'Mains', 'https://images.unsplash.com/photo-1630383249896-424e482df921?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(70, 5, 'Rava Dosa', 'Crispy semolina dosa with coconut chutney', 120.00, 55, 'Mains', 'https://images.unsplash.com/photo-1630383249896-424e482df921?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281')
ON CONFLICT DO NOTHING;

INSERT INTO menu_items (id, restaurant_id, name, description, price, stock_qty, category, image_url, created_at) VALUES
(71, 5, 'Idli Sambar (4 pcs)', 'Steamed rice cakes served with sambar and chutney', 110.00, 70, 'Mains', 'https://images.unsplash.com/photo-1606491956689-2ea866880c84?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(72, 5, 'Medu Vada (2 pcs)', 'Crispy fried lentil donuts with sambar and chutney', 100.00, 65, 'Mains', 'https://images.unsplash.com/photo-1606491956689-2ea866880c84?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(73, 5, 'Uttapam', 'Thick South Indian pancake with onion and tomato', 130.00, 50, 'Mains', 'https://images.unsplash.com/photo-1606491956689-2ea866880c84?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(74, 5, 'Pongal', 'Creamy rice-lentil porridge with black pepper and ghee', 120.00, 45, 'Mains', 'https://images.unsplash.com/photo-1606491956689-2ea866880c84?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(75, 5, 'Rava Idli (4 pcs)', 'Soft semolina idlis with coconut chutney and sambar', 125.00, 50, 'Mains', 'https://images.unsplash.com/photo-1606491956689-2ea866880c84?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(76, 1, 'Butter Naan', 'Soft leavened bread brushed with butter from tandoor', 50.00, 100, 'Mains', 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(77, 1, 'Garlic Naan', 'Naan topped with roasted garlic and fresh coriander', 60.00, 100, 'Mains', 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(78, 1, 'Tandoori Roti', 'Whole wheat roti from the clay tandoor oven', 35.00, 100, 'Mains', 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(79, 1, 'Stuffed Aloo Paratha', 'Whole wheat paratha stuffed with spiced potatoes', 90.00, 60, 'Mains', 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(80, 1, 'Laccha Paratha', 'Flaky layered whole wheat paratha with butter', 70.00, 70, 'Mains', 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(81, 1, 'Cheese Naan', 'Naan stuffed with gooey melted cheese', 80.00, 80, 'Mains', 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(82, 1, 'Mutton Rogan Josh', 'Classic Kashmiri mutton curry with aromatic spices', 380.00, 20, 'Mains', 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(83, 1, 'Mutton Keema', 'Minced mutton with green peas in spiced masala', 340.00, 20, 'Mains', 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(84, 1, 'Mutton Korma', 'Tender mutton in rich yogurt and almond gravy', 400.00, 20, 'Mains', 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(85, 1, 'Mutton Curry', 'Traditional slow-cooked mutton in spicy gravy', 360.00, 20, 'Mains', 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(86, 1, 'Mixed Veg Curry', 'Seasonal vegetables in aromatic Indian masala gravy', 190.00, 45, 'Mains', 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(87, 1, 'Aloo Gobi', 'Cauliflower and potato curry with turmeric and spices', 170.00, 45, 'Mains', 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.93281'),
(88, 6, 'Rasgulla', 'Soft spongy cottage cheese balls in light sugar syrup', 80.00, 60, 'Desserts', 'https://images.unsplash.com/photo-1607920592519-bab2a80efd77?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(89, 6, 'Rasmalai', 'Soft paneer patties soaked in saffron-flavoured cream', 110.00, 50, 'Desserts', 'https://images.unsplash.com/photo-1607920592519-bab2a80efd77?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(90, 6, 'Kheer', 'Creamy rice pudding with saffron, cardamom and nuts', 95.00, 55, 'Desserts', 'https://images.unsplash.com/photo-1607920592519-bab2a80efd77?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821')
ON CONFLICT DO NOTHING;

INSERT INTO menu_items (id, restaurant_id, name, description, price, stock_qty, category, image_url, created_at) VALUES
(91, 6, 'Phirni', 'Ground rice pudding with rosewater and pistachios', 100.00, 45, 'Desserts', 'https://images.unsplash.com/photo-1607920592519-bab2a80efd77?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(92, 6, 'Gajar Halwa', 'Grated carrot slow-cooked in milk, sugar and ghee', 110.00, 50, 'Desserts', 'https://images.unsplash.com/photo-1516684732162-798a0062be99?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(93, 6, 'Suji Halwa', 'Semolina pudding with saffron, cardamom and dry fruits', 90.00, 55, 'Desserts', 'https://images.unsplash.com/photo-1516684732162-798a0062be99?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(94, 6, 'Besan Ladoo', 'Gram flour balls with ghee, sugar and cardamom', 70.00, 70, 'Desserts', 'https://images.unsplash.com/photo-1515037893149-de7f840978e2?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(95, 6, 'Motichoor Ladoo', 'Fine boondi ladoo with cardamom and pistachios', 75.00, 65, 'Desserts', 'https://images.unsplash.com/photo-1515037893149-de7f840978e2?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(96, 6, 'Jalebi', 'Crispy spiral fried in sugar syrup, warm and golden', 65.00, 80, 'Desserts', 'https://images.unsplash.com/photo-1516684732162-798a0062be99?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(97, 6, 'Imarti', 'Crispy lentil spirals soaked in saffron sugar syrup', 70.00, 60, 'Desserts', 'https://images.unsplash.com/photo-1516684732162-798a0062be99?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(98, 6, 'Kaju Katli', 'Premium cashew fudge with silver leaf', 150.00, 40, 'Desserts', 'https://images.unsplash.com/photo-1515037893149-de7f840978e2?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(99, 6, 'Peda', 'Rich milk-based sweet with cardamom', 60.00, 70, 'Desserts', 'https://images.unsplash.com/photo-1515037893149-de7f840978e2?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(100, 6, 'Barfi', 'Milk fudge with coconut and pistachio topping', 80.00, 60, 'Desserts', 'https://images.unsplash.com/photo-1515037893149-de7f840978e2?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(101, 6, 'Sandesh', 'Bengali fresh cottage cheese sweet with jaggery', 85.00, 50, 'Desserts', 'https://images.unsplash.com/photo-1607920592519-bab2a80efd77?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(102, 6, 'Rabri', 'Thickened sweet milk with saffron and cardamom', 100.00, 45, 'Desserts', 'https://images.unsplash.com/photo-1607920592519-bab2a80efd77?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(103, 6, 'Malpua', 'Pancake soaked in sugar syrup with fennel seeds', 90.00, 50, 'Desserts', 'https://images.unsplash.com/photo-1516684732162-798a0062be99?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(104, 6, 'Modak', 'Steamed coconut-jaggery filled rice flour dumplings', 95.00, 45, 'Desserts', 'https://images.unsplash.com/photo-1515037893149-de7f840978e2?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(105, 6, 'Mysore Pak', 'Rich buttery gram flour sweet from Karnataka', 90.00, 50, 'Desserts', 'https://images.unsplash.com/photo-1515037893149-de7f840978e2?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(106, 6, 'Kalakand', 'Grainy milk cake with cardamom and rose water', 95.00, 45, 'Desserts', 'https://images.unsplash.com/photo-1607920592519-bab2a80efd77?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(107, 6, 'Shrikhand', 'Strained yogurt dessert with saffron and dry fruits', 100.00, 45, 'Desserts', 'https://images.unsplash.com/photo-1607920592519-bab2a80efd77?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(108, 6, 'Vanilla Ice Cream', 'Classic vanilla with creamy, smooth texture', 80.00, 80, 'Desserts', 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(109, 6, 'Chocolate Ice Cream', 'Rich dark chocolate scoop with chocolate chips', 85.00, 80, 'Desserts', 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(110, 6, 'Butterscotch Ice Cream', 'Creamy butterscotch with caramel swirl', 85.00, 75, 'Desserts', 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821')
ON CONFLICT DO NOTHING;

INSERT INTO menu_items (id, restaurant_id, name, description, price, stock_qty, category, image_url, created_at) VALUES
(111, 6, 'Mango Ice Cream', 'Alphonso mango flavoured creamy ice cream', 90.00, 70, 'Desserts', 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(112, 6, 'Kulfi (Malai)', 'Traditional Indian frozen dessert with pistachios', 100.00, 60, 'Desserts', 'https://images.unsplash.com/photo-1464305795204-6f5bbfc7fb81?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(113, 6, 'Kulfi (Mango)', U&'Mango kulfi on a stick \2014 creamy and refreshing', 105.00, 55, 'Desserts', 'https://images.unsplash.com/photo-1464305795204-6f5bbfc7fb81?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(114, 6, 'Sundae Delight', 'Two scoops of ice cream with chocolate fudge and nuts', 150.00, 40, 'Desserts', 'https://images.unsplash.com/photo-1464305795204-6f5bbfc7fb81?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(115, 6, 'Brownie Sundae', 'Warm brownie topped with ice cream and hot fudge sauce', 180.00, 35, 'Desserts', 'https://images.unsplash.com/photo-1551024601-bec78aea704b?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(116, 6, 'Chocolate Cake (slice)', 'Moist layered chocolate cake with ganache frosting', 130.00, 40, 'Desserts', 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(117, 6, 'Red Velvet Cake', 'Velvety red sponge with cream cheese frosting', 140.00, 35, 'Desserts', 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(118, 6, 'Biscoff Cheesecake', 'No-bake cheesecake with caramelised Biscoff topping', 160.00, 30, 'Desserts', 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(119, 6, 'Tiramisu', 'Italian ladyfingers soaked in espresso with mascarpone', 150.00, 30, 'Desserts', 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(120, 6, 'Chocolate Mousse', 'Light airy dark chocolate mousse with berries', 130.00, 35, 'Desserts', 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(121, 6, 'Lava Cake', 'Warm chocolate fondant with gooey molten centre', 140.00, 35, 'Desserts', 'https://images.unsplash.com/photo-1551024601-bec78aea704b?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(122, 6, 'Waffle with Syrup', 'Belgian waffle with maple syrup and butter', 140.00, 40, 'Desserts', 'https://images.unsplash.com/photo-1464305795204-6f5bbfc7fb81?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(123, 6, 'Panna Cotta', 'Italian silky vanilla cream dessert with berry coulis', 135.00, 30, 'Desserts', 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(124, 6, 'Gulab Jamun Ice Cream', 'Vanilla ice cream topped with warm gulab jamun', 160.00, 30, 'Desserts', 'https://images.unsplash.com/photo-1533993192821-2cce3a8267d?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(125, 6, 'Jalebi Rabri', 'Hot crispy jalebi served with chilled rabri', 120.00, 40, 'Desserts', 'https://images.unsplash.com/photo-1516684732162-798a0062be99?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(126, 6, 'Chocolate Paan', 'Betel leaf filled with chocolate and dry fruits', 80.00, 50, 'Desserts', 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(127, 6, 'Seviyan Kheer', 'Vermicelli cooked in sweet saffron-milk', 90.00, 50, 'Desserts', 'https://images.unsplash.com/photo-1607920592519-bab2a80efd77?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.957821'),
(128, 2, 'Paneer Tikka (6 pcs)', 'Marinated paneer grilled in tandoor with mint chutney', 200.00, 40, 'Starters', 'https://images.unsplash.com/photo-1574484284002-952d92456975?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.969237'),
(129, 2, 'Veg Seekh Kebab', 'Minced vegetable kebabs grilled on skewers', 170.00, 35, 'Starters', 'https://images.unsplash.com/photo-1574484284002-952d92456975?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.969237')
ON CONFLICT DO NOTHING;

INSERT INTO menu_items (id, restaurant_id, name, description, price, stock_qty, category, image_url, created_at) VALUES
(130, 2, 'Tandoori Chicken (half)', 'Chicken marinated in yogurt spices, grilled in clay oven', 280.00, 25, 'Starters', 'https://images.unsplash.com/photo-1600891964092-4316c288032e?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.969237'),
(131, 2, 'Chicken Seekh Kebab', 'Minced chicken skewers with coriander and chilli', 230.00, 30, 'Starters', 'https://images.unsplash.com/photo-1600891964092-4316c288032e?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.969237'),
(132, 2, 'Mutton Seekh Kebab', 'Juicy minced mutton skewers from the tandoor', 270.00, 25, 'Starters', 'https://images.unsplash.com/photo-1574484284002-952d92456975?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.969237'),
(133, 2, 'Samosa (2 pcs)', 'Crispy fried pastry filled with spiced potatoes and peas', 70.00, 80, 'Starters', 'https://images.unsplash.com/photo-1574484284002-952d92456975?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.969237'),
(134, 2, 'Onion Pakoda', 'Crispy onion fritters with chaat masala and chutney', 80.00, 70, 'Starters', 'https://images.unsplash.com/photo-1574484284002-952d92456975?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.969237'),
(135, 2, 'Gobi Manchurian', 'Crispy cauliflower in Indo-Chinese Manchurian sauce', 150.00, 40, 'Starters', 'https://images.unsplash.com/photo-1617622141675-d3005b9d5e8a?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.969237'),
(136, 2, 'Chilli Chicken (dry)', 'Crispy chicken tossed in spicy Indo-Chinese chilli sauce', 200.00, 35, 'Starters', 'https://images.unsplash.com/photo-1617622141675-d3005b9d5e8a?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.969237'),
(137, 2, 'Chicken Wings (6 pcs)', 'Honey-glazed crispy chicken wings with dip', 220.00, 30, 'Starters', 'https://images.unsplash.com/photo-1600891964092-4316c288032e?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.969237'),
(138, 2, 'Prawn Tempura (4 pcs)', 'Japanese-style battered prawns with dipping sauce', 250.00, 25, 'Starters', 'https://images.unsplash.com/photo-1617622141675-d3005b9d5e8a?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.969237'),
(139, 2, 'Fish Fry', 'Crispy battered fish fillet with tartar sauce', 220.00, 30, 'Starters', 'https://images.unsplash.com/photo-1574484284002-952d92456975?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.969237'),
(140, 2, 'Cheese Corn Nuggets', 'Golden fried corn and cheese nuggets', 140.00, 45, 'Starters', 'https://images.unsplash.com/photo-1617622141675-d3005b9d5e8a?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.969237'),
(141, 2, 'Potato Wedges', 'Oven-roasted potato wedges with herb seasoning', 110.00, 55, 'Starters', 'https://images.unsplash.com/photo-1574484284002-952d92456975?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.969237'),
(142, 2, 'Masala Papad', 'Roasted papad topped with onion, tomato and chaat masala', 60.00, 80, 'Starters', 'https://images.unsplash.com/photo-1574484284002-952d92456975?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.969237'),
(143, 4, 'Mushroom Swiss Burger', U&'Saut\00e9ed mushrooms with Swiss cheese and garlic mayo', 190.00, 25, 'Burgers', 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.973237'),
(144, 4, 'Double Smash Burger', 'Double smashed beef patties with special burger sauce', 260.00, 20, 'Burgers', 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.973237'),
(145, 4, 'Veggie Burger', 'Crispy veggie patty with fresh lettuce, tomato and sauce', 140.00, 30, 'Burgers', 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.973237'),
(146, 4, 'BBQ Chicken Burger', 'Grilled chicken with smoky BBQ sauce and onion rings', 200.00, 25, 'Burgers', 'https://images.unsplash.com/photo-1561758033-d89a9ad46330?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.973237'),
(147, 4, 'Paneer Burger', 'Crispy paneer patty with mint mayo and onion', 170.00, 30, 'Burgers', 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.973237'),
(148, 4, 'Egg Burger', 'Fried egg with cheese, lettuce and hot sauce', 160.00, 30, 'Burgers', 'https://images.unsplash.com/photo-1561758033-d89a9ad46330?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.973237')
ON CONFLICT DO NOTHING;

INSERT INTO menu_items (id, restaurant_id, name, description, price, stock_qty, category, image_url, created_at) VALUES
(149, 4, 'Loaded Fries Burger', 'Burger served with a loaded side of cheese fries', 230.00, 20, 'Burgers', 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.973237'),
(150, 4, 'Fish Fillet Burger', 'Crispy battered fish with tartare sauce and coleslaw', 210.00, 20, 'Burgers', 'https://images.unsplash.com/photo-1561758033-d89a9ad46330?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.973237'),
(151, 4, 'Margherita Pizza', 'Classic tomato, fresh mozzarella and basil leaves', 220.00, 30, 'Pizza', 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.97646'),
(152, 4, 'Pepperoni Pizza', 'Loaded pepperoni with mozzarella on tomato base', 320.00, 25, 'Pizza', 'https://images.unsplash.com/photo-1528137871618-79d2761e3fd5?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.97646'),
(153, 4, 'BBQ Chicken Pizza', 'Grilled chicken, caramelised onion and smoky BBQ sauce', 340.00, 20, 'Pizza', 'https://images.unsplash.com/photo-1528137871618-79d2761e3fd5?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.97646'),
(154, 4, 'Paneer Tikka Pizza', 'Marinated paneer with capsicum and tikka sauce', 310.00, 25, 'Pizza', 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.97646'),
(155, 4, 'Veggie Supreme Pizza', 'Loaded with bell peppers, olives, corn and mushroom', 280.00, 25, 'Pizza', 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.97646'),
(156, 4, 'Four Cheese Pizza', 'Mozzarella, cheddar, parmesan and ricotta blend', 360.00, 20, 'Pizza', 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.97646'),
(157, 4, 'Pesto Chicken Pizza', 'Chicken strips on basil pesto base with parmesan', 330.00, 20, 'Pizza', 'https://images.unsplash.com/photo-1528137871618-79d2761e3fd5?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.97646'),
(158, 4, 'Spicy Mexican Pizza', U&'Jalape\00f1os, beans, corn with chipotle and cheese', 300.00, 20, 'Pizza', 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.97646'),
(159, 3, 'Chicken Hakka Noodles', 'Wok-tossed noodles with chicken and vegetables', 180.00, 35, 'Noodles', 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.980468'),
(160, 3, 'Egg Noodles', 'Stir-fried noodles with scrambled egg and soy', 160.00, 40, 'Noodles', 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.980468'),
(161, 3, 'Schezwan Noodles', 'Spicy Schezwan sauce noodles with vegetables', 170.00, 35, 'Noodles', 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.980468'),
(162, 3, 'Singapore Noodles', 'Thin rice noodles with curry powder and vegetables', 165.00, 30, 'Noodles', 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.980468'),
(163, 3, 'Pad Thai Noodles', 'Thai-style flat noodles with peanuts and spring onion', 200.00, 25, 'Noodles', 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.980468'),
(164, 3, 'Ramen Bowl', 'Japanese-style ramen in rich broth with noodles', 250.00, 25, 'Noodles', 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.980468'),
(165, 3, 'Udon Noodles', 'Thick Japanese udon in miso broth with tofu', 230.00, 20, 'Noodles', 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.980468'),
(166, 3, 'Chicken Chow Mein', 'Classic crispy chow mein noodles with chicken', 190.00, 30, 'Noodles', 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.980468'),
(167, 6, 'Rose Sharbat', 'Chilled rose syrup drink with fresh seeds and milk', 70.00, 70, 'Drinks', 'https://images.unsplash.com/photo-1544145945-f90425340c7e?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.984458')
ON CONFLICT DO NOTHING;

INSERT INTO menu_items (id, restaurant_id, name, description, price, stock_qty, category, image_url, created_at) VALUES
(168, 6, 'Buttermilk (Chaas)', 'Salted spiced yogurt drink with curry leaves', 50.00, 80, 'Drinks', 'https://images.unsplash.com/photo-1590301157890-4810ed352733?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.984458'),
(169, 6, 'Strawberry Milkshake', 'Thick creamy strawberry milkshake with fresh berries', 110.00, 50, 'Drinks', 'https://images.unsplash.com/photo-1544145945-f90425340c7e?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.984458'),
(170, 6, 'Chocolate Milkshake', 'Rich blended chocolate milkshake with whipped cream', 115.00, 50, 'Drinks', 'https://images.unsplash.com/photo-1544145945-f90425340c7e?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.984458'),
(171, 6, 'Watermelon Juice', 'Fresh watermelon juice with a hint of mint', 70.00, 65, 'Drinks', 'https://images.unsplash.com/photo-1621263764928-df1444c5e859?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.984458'),
(172, 6, 'Pineapple Juice', 'Freshly squeezed pineapple juice with ginger', 75.00, 60, 'Drinks', 'https://images.unsplash.com/photo-1621263764928-df1444c5e859?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.984458'),
(173, 6, 'Masala Chai', 'Spiced Indian tea brewed with ginger and cardamom', 40.00, 100, 'Drinks', 'https://images.unsplash.com/photo-1544145945-f90425340c7e?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.984458'),
(174, 6, 'Filter Coffee', 'South Indian strong filter coffee with frothy milk', 50.00, 90, 'Drinks', 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.984458'),
(175, 6, 'Virgin Mojito', U&'Fresh lime, mint and soda \2014 cool and refreshing', 90.00, 60, 'Drinks', 'https://images.unsplash.com/photo-1621263764928-df1444c5e859?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.984458'),
(176, 6, 'Tender Coconut Water', U&'Fresh tender coconut water \2014 natural electrolytes', 80.00, 55, 'Drinks', 'https://images.unsplash.com/photo-1590301157890-4810ed352733?w=400&q=80', TIMESTAMP '2026-09-05 18:26:38.984458')
ON CONFLICT DO NOTHING;

SELECT setval(pg_get_serial_sequence('users', 'id'), (SELECT COALESCE(MAX(id), 0) + 1 FROM users), false);
SELECT setval(pg_get_serial_sequence('restaurants', 'id'), (SELECT COALESCE(MAX(id), 0) + 1 FROM restaurants), false);
SELECT setval(pg_get_serial_sequence('menu_items', 'id'), (SELECT COALESCE(MAX(id), 0) + 1 FROM menu_items), false);
COMMIT;