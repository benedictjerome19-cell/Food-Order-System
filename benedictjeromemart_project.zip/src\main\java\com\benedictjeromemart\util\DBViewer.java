package com.benedictjeromemart.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DBViewer {
    public static void main(String[] args) {
        // Render External Database credentials converted to JDBC format
        String url = "jdbc:postgresql://dpg-dan44m142hec73d535bg-a.oregon-postgres.render.com:5432/benedictjeromemart_db?sslmode=require";
        String user = "benedictjeromemart_db_user";
        String password = "3hAmYmzSSwaSTy9mDgUO7bs9AgiEsrQ4";

        System.out.println("Connecting to Render PostgreSQL Database...");

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement()) {
            
            System.out.println("✅ CONNECTED SUCCESSFULLY!\n");
            
            // Fetch and print the Users table
            System.out.println("=== 👤 USERS TABLE ===");
            ResultSet rsUsers = stmt.executeQuery("SELECT id, name, email, role FROM users LIMIT 10;");
            while (rsUsers.next()) {
                System.out.printf("ID: %-3d | Name: %-15s | Email: %-25s | Role: %s%n",
                        rsUsers.getInt("id"), 
                        rsUsers.getString("name"), 
                        rsUsers.getString("email"), 
                        rsUsers.getString("role"));
            }
            
            // Fetch and print the Menu Items table
            System.out.println("\n=== 🍔 MENU ITEMS TABLE ===");
            ResultSet rsMenu = stmt.executeQuery("SELECT id, name, price FROM menu_items LIMIT 10;");
            while (rsMenu.next()) {
                System.out.printf("ID: %-3d | Name: %-25s | Price: Rs. %s%n",
                        rsMenu.getInt("id"), 
                        rsMenu.getString("name"), 
                        rsMenu.getBigDecimal("price"));
            }

            System.out.println("\n✅ Data fetch complete!");

        } catch (Exception e) {
            System.err.println("❌ Connection failed:");
            e.printStackTrace();
        }
    }
}